import * as faceapi from 'face-api.js';

// Load models
export const loadModels = async () => {
  try {
    await Promise.all([
      faceapi.nets.ssdMobilenetv1.loadFromUri('/models'),
      faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
      faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
      faceapi.nets.faceExpressionNet.loadFromUri('/models')
    ]);
    console.log('Face-api models loaded successfully');
    return true;
  } catch (error) {
    console.error('Error loading face-api models:', error);
    return false;
  }
};

// Get face descriptor from image or video element
export const getFaceDescriptor = async (
  mediaElement: HTMLImageElement | HTMLVideoElement
): Promise<Float32Array | null> => {
  try {
    const detections = await faceapi
      .detectSingleFace(mediaElement)
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (!detections) {
      console.log('No face detected');
      return null;
    }

    return detections.descriptor;
  } catch (error) {
    console.error('Error getting face descriptor:', error);
    return null;
  }
};

// Compare face descriptors and return distance (lower is better match)
export const compareFaces = (
  descriptor1: Float32Array,
  descriptor2: Float32Array | string
): number => {
  // If descriptor2 is a string (from DB), convert it to Float32Array
  const descriptor2Array = typeof descriptor2 === 'string' 
    ? new Float32Array(JSON.parse(descriptor2)) 
    : descriptor2;
    
  return faceapi.euclideanDistance(descriptor1, descriptor2Array);
};

// Verify if face matches with stored descriptor
export const verifyFace = (
  currentDescriptor: Float32Array,
  storedDescriptor: string,
  threshold = 0.6
): boolean => {
  const distance = compareFaces(currentDescriptor, storedDescriptor);
  return distance < threshold;
};

// Convert descriptor to string for storage
export const descriptorToString = (descriptor: Float32Array): string => {
  return JSON.stringify(Array.from(descriptor));
};

// Draw face detection results on canvas
export const drawFaceDetection = async (
  mediaElement: HTMLImageElement | HTMLVideoElement,
  canvas: HTMLCanvasElement
) => {
  const displaySize = {
    width: mediaElement.width,
    height: mediaElement.height
  };
  
  // Match canvas size to media element
  faceapi.matchDimensions(canvas, displaySize);
  
  // Detect faces
  const detections = await faceapi
    .detectAllFaces(mediaElement)
    .withFaceLandmarks()
    .withFaceExpressions();
    
  // Resize detections to match display size
  const resizedDetections = faceapi.resizeResults(detections, displaySize);
  
  // Clear canvas
  canvas.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
  
  // Draw detections
  faceapi.draw.drawDetections(canvas, resizedDetections);
  faceapi.draw.drawFaceLandmarks(canvas, resizedDetections);
  faceapi.draw.drawFaceExpressions(canvas, resizedDetections);
};