import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase credentials missing. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env file');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

export type UserRole = 'admin' | 'student';

export interface User {
  id: string;
  email: string;
  role: UserRole;
}

export interface Student {
  id: string;
  user_id: string;
  name: string;
  email: string;
  student_id: string;
  course: string;
  year: number;
  face_data?: string;
  created_at: string;
}

export interface Attendance {
  id: string;
  student_id: string;
  date: string;
  time: string;
  status: 'present' | 'absent';
  method: 'face' | 'manual';
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  due_date: string;
  course: string;
}

export interface Exam {
  id: string;
  title: string;
  date: string;
  time: string;
  course: string;
  location: string;
}