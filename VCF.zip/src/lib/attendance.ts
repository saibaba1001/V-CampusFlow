import { supabase, Attendance } from './supabase';

export const markAttendance = async (studentId: string, method: 'face' | 'manual'): Promise<Attendance> => {
  const now = new Date();
  const date = now.toISOString().split('T')[0];
  const time = now.toISOString().split('T')[1].split('.')[0];
  
  // Check if attendance already marked for today
  const { data: existingAttendance } = await supabase
    .from('attendance')
    .select('*')
    .eq('student_id', studentId)
    .eq('date', date);
    
  if (existingAttendance && existingAttendance.length > 0) {
    // Update existing attendance
    const { data, error } = await supabase
      .from('attendance')
      .update({ 
        status: 'present', 
        time, 
        method 
      })
      .eq('student_id', studentId)
      .eq('date', date)
      .select()
      .single();
      
    if (error) throw error;
    return data;
  } else {
    // Create new attendance record
    const { data, error } = await supabase
      .from('attendance')
      .insert([
        { 
          student_id: studentId, 
          date, 
          time, 
          status: 'present', 
          method 
        }
      ])
      .select()
      .single();
      
    if (error) throw error;
    return data;
  }
};

export const getAttendanceByStudent = async (studentId: string): Promise<Attendance[]> => {
  const { data, error } = await supabase
    .from('attendance')
    .select('*')
    .eq('student_id', studentId)
    .order('date', { ascending: false });
    
  if (error) throw error;
  return data || [];
};

export const getAttendanceByDate = async (date: string): Promise<Attendance[]> => {
  const { data, error } = await supabase
    .from('attendance')
    .select('*')
    .eq('date', date);
    
  if (error) throw error;
  return data || [];
};

export const getAttendanceStats = async (studentId: string): Promise<{ total: number; present: number; percentage: number }> => {
  const { data, error } = await supabase
    .from('attendance')
    .select('*')
    .eq('student_id', studentId);
    
  if (error) throw error;
  
  const total = data?.length || 0;
  const present = data?.filter(a => a.status === 'present').length || 0;
  const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
  
  return { total, present, percentage };
};