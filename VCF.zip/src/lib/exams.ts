import { supabase, Exam } from './supabase';

export const getExams = async (): Promise<Exam[]> => {
  const { data, error } = await supabase
    .from('exams')
    .select('*')
    .order('date');
    
  if (error) throw error;
  return data || [];
};

export const getExamById = async (id: string): Promise<Exam | null> => {
  const { data, error } = await supabase
    .from('exams')
    .select('*')
    .eq('id', id)
    .single();
    
  if (error && error.code !== 'PGRST116') throw error;
  return data || null;
};

export const createExam = async (exam: Omit<Exam, 'id'>): Promise<Exam> => {
  const { data, error } = await supabase
    .from('exams')
    .insert([exam])
    .select()
    .single();
    
  if (error) throw error;
  return data;
};

export const updateExam = async (id: string, updates: Partial<Exam>): Promise<Exam> => {
  const { data, error } = await supabase
    .from('exams')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
    
  if (error) throw error;
  return data;
};

export const deleteExam = async (id: string): Promise<void> => {
  const { error } = await supabase
    .from('exams')
    .delete()
    .eq('id', id);
    
  if (error) throw error;
};