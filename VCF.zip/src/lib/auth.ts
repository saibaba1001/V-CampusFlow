import { supabase, UserRole } from './supabase';

export const signUp = async (email: string, password: string, role: UserRole = 'student') => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        role,
      },
    },
  });

  if (error) throw error;
  
  // If it's an admin signup, verify domain
  if (role === 'admin' && !email.endsWith('@school.com')) {
    throw new Error('Admin emails must use the @school.com domain');
  }

  return data;
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const getCurrentUser = async () => {
  const { data: { session }, error } = await supabase.auth.getSession();
  
  if (error) throw error;
  if (!session?.user) return null;
  
  return {
    id: session.user.id,
    email: session.user.email,
    role: session.user.user_metadata?.role || 'student',
  };
};

export const getUserRole = async (): Promise<UserRole | null> => {
  const { data: { session }, error } = await supabase.auth.getSession();
  
  if (error || !session?.user) return null;
  return session.user.user_metadata?.role as UserRole || null;
};