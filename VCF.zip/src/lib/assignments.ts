import { supabase, Assignment } from './supabase';

export const getAssignments = async (): Promise<Assignment[]> => {
  const { data, error } = await supabase
    .from('assignments')
    .select('*')
    .order('due_date');
    
  if (error) throw error;
  return data || [];
};

export const getAssignmentById = async (id: string): Promise<Assignment | null> => {
  const { data, error } = await supabase
    .from('assignments')
    .select('*')
    .eq('id', id)
    .single();
    
  if (error && error.code !== 'PGRST116') throw error;
  return data || null;
};

export const createAssignment = async (assignment: Omit<Assignment, 'id'>): Promise<Assignment> => {
  const { data, error } = await supabase
    .from('assignments')
    .insert([assignment])
    .select()
    .single();
    
  if (error) throw error;
  return data;
};

export const updateAssignment = async (id: string, updates: Partial<Assignment>): Promise<Assignment> => {
  const { data, error } = await supabase
    .from('assignments')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
    
  if (error) throw error;
  return data;
};

export const deleteAssignment = async (id: string): Promise<void> => {
  const { error } = await supabase
    .from('assignments')
    .delete()
    .eq('id', id);
    
  if (error) throw error;
};