import React, { useRef, useState, useEffect } from 'react';
import Webcam from 'react-webcam';
import { Camera, Check, AlertCircle } from 'lucide-react';
import { loadModels, getFaceDescriptor, verifyFace } from '../lib/face-api';

interface FaceRecognitionProps {
  storedFaceData: string;
  onSuccess: () => void;
  onError: (error: string) => void;
}

const FaceRecognition: React.FC<FaceRecognitionProps> = ({ 
  storedFaceData, 
  onSuccess, 
  onError 
}) => {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [isVerifying, setIsVerifying] = useState(false);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  
  // Load face-api models on component mount
  useEffect(() => {
    const loadFaceModels = async () => {
      try {
        const loaded = await loadModels();
        setModelsLoaded(loaded);
      } catch (error) {
        console.error('Error loading face models:', error);
        setVerifyError('Failed to load face recognition models. Please try again.');
        onError('Failed to load face recognition models');
      }
    };
    
    loadFaceModels();
  }, [onError]);
  
  const startVerification = () => {
    if (!modelsLoaded) {
      setVerifyError('Face recognition models not loaded yet. Please wait.');
      onError('Face recognition models not loaded yet');
      return;
    }
    
    if (!storedFaceData) {
      setVerifyError('No face data available for comparison. Please register your face first.');
      onError('No face data available for comparison');
      return;
    }
    
    setIsVerifying(true);
    setVerifyError(null);
    setCountdown(3);
  };
  
  // Countdown effect
  useEffect(() => {
    if (countdown === null) return;
    
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      // When countdown reaches zero, verify the face
      verifyFaceData();
    }
  }, [countdown]);
  
  const verifyFaceData = async () => {
    if (!webcamRef.current?.video) return;
    
    try {
      const descriptor = await getFaceDescriptor(webcamRef.current.video);
      
      if (!descriptor) {
        setVerifyError('No face detected. Please position your face in the center of the camera.');
        setIsVerifying(false);
        onError('No face detected');
        return;
      }
      
      // Verify against stored face data
      const isMatch = verifyFace(descriptor, storedFaceData);
      
      if (isMatch) {
        onSuccess();
      } else {
        setVerifyError('Face verification failed. Please try again or use manual attendance.');
        onError('Face verification failed');
      }
      
      setIsVerifying(false);
    } catch (error) {
      console.error('Error verifying face:', error);
      setVerifyError('Failed to verify face. Please try again.');
      setIsVerifying(false);
      onError('Failed to verify face');
    }
  };
  
  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <div className="mb-4 flex items-center space-x-2">
        <Camera className="w-5 h-5 text-primary-600" />
        <h2 className="text-lg font-semibold">Face Recognition</h2>
      </div>
      
      <div className="relative">
        {isVerifying && (
          <div className="absolute inset-0 flex items-center justify-center z-10">
            {countdown !== null && countdown > 0 && (
              <div className="bg-black/50 rounded-full w-20 h-20 flex items-center justify-center">
                <span className="text-4xl text-white font-bold">{countdown}</span>
              </div>
            )}
          </div>
        )}
        
        <div className="relative bg-gray-200 rounded-lg overflow-hidden mb-4">
          <Webcam
            ref={webcamRef}
            className="w-full h-auto"
            mirrored
            videoConstraints={{
              width: 640,
              height: 480,
              facingMode: 'user',
            }}
          />
          <canvas 
            ref={canvasRef} 
            className="absolute top-0 left-0 w-full h-full"
          />
        </div>
      </div>
      
      {verifyError && (
        <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5" />
          <span>{verifyError}</span>
        </div>
      )}
      
      <div className="flex justify-center">
        <button
          onClick={startVerification}
          disabled={isVerifying || !modelsLoaded}
          className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
            isVerifying || !modelsLoaded
              ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
              : 'bg-primary-600 text-white hover:bg-primary-700'
          }`}
        >
          {isVerifying ? (
            <>
              <span className="animate-pulse">Verifying...</span>
            </>
          ) : (
            <>
              <Check className="w-5 h-5" />
              <span>Start Face Verification</span>
            </>
          )}
        </button>
      </div>
      
      <div className="mt-4 text-sm text-gray-500">
        <p>
          Please position your face in the frame and click the button to verify.
          Make sure your face is well-lit and looking directly at the camera.
        </p>
      </div>
    </div>
  );
};

export default FaceRecognition;