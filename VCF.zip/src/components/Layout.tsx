import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, User, BarChart2, BookOpen, Calendar, Home } from 'lucide-react';
import { signOut } from '../lib/auth';
import { useUserStore } from '../store/userStore';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { user, clearUser } = useUserStore();
  const navigate = useNavigate();
  
  const handleLogout = async () => {
    try {
      await signOut();
      clearUser();
      navigate('/login');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };
  
  if (!user) return <>{children}</>;
  
  const isAdmin = user.role === 'admin';
  const navBgColor = isAdmin ? 'bg-admin-800' : 'bg-student-800';
  const navHoverColor = isAdmin ? 'hover:bg-admin-700' : 'hover:bg-student-700';
  const mainBgColor = isAdmin ? 'bg-admin-50' : 'bg-student-50';
  
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className={`w-20 md:w-64 ${navBgColor} text-white transition-all duration-300 ease-in-out`}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-white/10">
            <div className="hidden md:block text-xl font-bold">V-CampusFlow</div>
            <div className="block md:hidden text-xl font-bold text-center">FA</div>
          </div>
          
          <nav className="flex-1 overflow-y-auto py-4">
            <ul className="space-y-2 px-2">
              <li>
                <Link 
                  to={isAdmin ? '/admin' : '/student'} 
                  className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                >
                  <Home className="w-6 h-6" />
                  <span className="hidden md:block ml-3">Dashboard</span>
                </Link>
              </li>
              
              {isAdmin ? (
                <>
                  <li>
                    <Link 
                      to="/admin/students" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <User className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Students</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/admin/attendance" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <BarChart2 className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Attendance</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/admin/assignments" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <BookOpen className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Assignments</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/admin/exams" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <Calendar className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Exams</span>
                    </Link>
                  </li>
                </>
              ) : (
                <>
                  <li>
                    <Link 
                      to="/student/profile" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <User className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Profile</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/student/attendance" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <BarChart2 className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Attendance</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/student/assignments" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <BookOpen className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Assignments</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/student/exams" 
                      className={`flex items-center p-2 rounded-lg ${navHoverColor} transition-colors`}
                    >
                      <Calendar className="w-6 h-6" />
                      <span className="hidden md:block ml-3">Exams</span>
                    </Link>
                  </li>
                </>
              )}
            </ul>
          </nav>
          
          <div className="p-4 border-t border-white/10">
            <button 
              onClick={handleLogout}
              className={`flex items-center w-full p-2 rounded-lg ${navHoverColor} transition-colors`}
            >
              <LogOut className="w-6 h-6" />
              <span className="hidden md:block ml-3">Logout</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className={`flex-1 overflow-y-auto ${mainBgColor}`}>
        <div className="container mx-auto p-4 md:p-6">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Layout;