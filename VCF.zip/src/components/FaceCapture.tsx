import React, { useRef, useState, useEffect, useCallback } from 'react';
import Webcam from 'react-webcam';
import { Camera, User, Check, AlertCircle } from 'lucide-react';
import { loadModels, getFaceDescriptor, descriptorToString } from '../lib/face-api';

interface FaceCaptureProps {
  onCapture: (faceDescriptor: string) => void;
  buttonText?: string;
}

const FaceCapture: React.FC<FaceCaptureProps> = ({ 
  onCapture, 
  buttonText = 'Capture Face'
}) => {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [isCapturing, setIsCapturing] = useState(false);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [captureError, setCaptureError] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  
  // Load face-api models on component mount
  useEffect(() => {
    const loadFaceModels = async () => {
      try {
        const loaded = await loadModels();
        setModelsLoaded(loaded);
      } catch (error) {
        console.error('Error loading face models:', error);
        setCaptureError('Failed to load face recognition models. Please try again.');
      }
    };
    
    loadFaceModels();
    
    // Create /public/models directory if it doesn't exist
    console.log('Make sure to download face-api.js models to /public/models directory');
  }, []);
  
  const startCapture = () => {
    if (!modelsLoaded) {
      setCaptureError('Face recognition models not loaded yet. Please wait.');
      return;
    }
    
    setIsCapturing(true);
    setCaptureError(null);
    setCountdown(3);
  };
  
  // Countdown effect
  useEffect(() => {
    if (countdown === null) return;
    
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      // When countdown reaches zero, capture the face
      captureFace();
    }
  }, [countdown]);
  
  const captureFace = useCallback(async () => {
    if (!webcamRef.current?.video) return;
    
    try {
      const descriptor = await getFaceDescriptor(webcamRef.current.video);
      
      if (!descriptor) {
        setCaptureError('No face detected. Please position your face in the center of the camera.');
        setIsCapturing(false);
        return;
      }
      
      // Convert descriptor to string for storage
      const descriptorString = descriptorToString(descriptor);
      onCapture(descriptorString);
      setIsCapturing(false);
    } catch (error) {
      console.error('Error capturing face:', error);
      setCaptureError('Failed to capture face. Please try again.');
      setIsCapturing(false);
    }
  }, [onCapture]);
  
  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <div className="mb-4 flex items-center space-x-2">
        <Camera className="w-5 h-5 text-primary-600" />
        <h2 className="text-lg font-semibold">Face Registration</h2>
      </div>
      
      <div className="relative">
        {isCapturing && (
          <div className="absolute inset-0 flex items-center justify-center z-10">
            {countdown !== null && countdown > 0 && (
              <div className="bg-black/50 rounded-full w-20 h-20 flex items-center justify-center">
                <span className="text-4xl text-white font-bold">{countdown}</span>
              </div>
            )}
          </div>
        )}
        
        <div className="relative bg-gray-200 rounded-lg overflow-hidden mb-4">
          <Webcam
            ref={webcamRef}
            className="w-full h-auto"
            mirrored
            videoConstraints={{
              width: 640,
              height: 480,
              facingMode: 'user',
            }}
          />
          <canvas 
            ref={canvasRef} 
            className="absolute top-0 left-0 w-full h-full"
          />
        </div>
      </div>
      
      {captureError && (
        <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5" />
          <span>{captureError}</span>
        </div>
      )}
      
      <div className="flex justify-center">
        <button
          onClick={startCapture}
          disabled={isCapturing || !modelsLoaded}
          className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
            isCapturing || !modelsLoaded
              ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
              : 'bg-primary-600 text-white hover:bg-primary-700'
          }`}
        >
          {isCapturing ? (
            <>
              <span className="animate-pulse">Processing...</span>
            </>
          ) : (
            <>
              <User className="w-5 h-5" />
              <span>{buttonText}</span>
            </>
          )}
        </button>
      </div>
      
      <div className="mt-4 text-sm text-gray-500">
        <p>
          Make sure your face is well-lit and looking directly at the camera.
          Remove glasses and ensure no obstructions.
        </p>
      </div>
    </div>
  );
};

export default FaceCapture;