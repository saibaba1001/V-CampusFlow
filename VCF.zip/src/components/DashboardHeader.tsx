import React from 'react';
import { useUserStore } from '../store/userStore';

interface DashboardHeaderProps {
  title: string;
  subtitle?: string;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({ title, subtitle }) => {
  const { user } = useUserStore();
  const isAdmin = user?.role === 'admin';
  const headerColor = isAdmin ? 'from-admin-600 to-admin-800' : 'from-student-600 to-student-800';
  
  return (
    <div className={`bg-gradient-to-r ${headerColor} rounded-lg shadow-md p-6 mb-6 text-white animate-fade-in`}>
      <h1 className="text-2xl font-bold">{title}</h1>
      {subtitle && <p className="text-white/80 mt-1">{subtitle}</p>}
    </div>
  );
};

export default DashboardHeader;