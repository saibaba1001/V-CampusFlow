import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useUserStore } from './store/userStore';
import { getCurrentUser } from './lib/auth';

// Auth pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

// Admin pages
import AdminDashboard from './pages/admin/Dashboard';
import AdminStudents from './pages/admin/Students';
import AdminStudentDetail from './pages/admin/StudentDetail';
import AdminAttendance from './pages/admin/Attendance';
import AdminAssignments from './pages/admin/Assignments';
import AdminExams from './pages/admin/Exams';

// Student pages
import StudentDashboard from './pages/student/Dashboard';
import StudentProfile from './pages/student/Profile';
import StudentAttendance from './pages/student/Attendance';
import StudentAssignments from './pages/student/Assignments';
import StudentExams from './pages/student/Exams';

// Shared components
import Layout from './components/Layout';

const ProtectedRoute: React.FC<{
  element: React.ReactNode;
  allowedRole?: 'admin' | 'student';
}> = ({ element, allowedRole }) => {
  const { user } = useUserStore();
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (allowedRole && user.role !== allowedRole) {
    return <Navigate to={user.role === 'admin' ? '/admin' : '/student'} replace />;
  }
  
  return <>{element}</>;
};

function App() {
  const { user, setUser } = useUserStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await getCurrentUser();
        if (currentUser) {
          setUser(currentUser);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Error fetching user:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [setUser]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-pulse flex flex-col items-center">
          <div className="w-12 h-12 border-4 border-t-primary-500 border-gray-200 rounded-full animate-spin"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        {/* Auth Routes */}
        <Route
          path="/login"
          element={user ? <Navigate to={user.role === 'admin' ? '/admin' : '/student'} /> : <Login />}
        />
        <Route
          path="/register"
          element={user ? <Navigate to={user.role === 'admin' ? '/admin' : '/student'} /> : <Register />}
        />

        {/* Admin Routes */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <AdminDashboard />
                </Layout>
              }
              allowedRole="admin"
            />
          }
        />
        <Route
          path="/admin/students"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <AdminStudents />
                </Layout>
              }
              allowedRole="admin"
            />
          }
        />
        <Route
          path="/admin/students/:id"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <AdminStudentDetail />
                </Layout>
              }
              allowedRole="admin"
            />
          }
        />
        <Route
          path="/admin/attendance"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <AdminAttendance />
                </Layout>
              }
              allowedRole="admin"
            />
          }
        />
        <Route
          path="/admin/assignments"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <AdminAssignments />
                </Layout>
              }
              allowedRole="admin"
            />
          }
        />
        <Route
          path="/admin/exams"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <AdminExams />
                </Layout>
              }
              allowedRole="admin"
            />
          }
        />

        {/* Student Routes */}
        <Route
          path="/student"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <StudentDashboard />
                </Layout>
              }
              allowedRole="student"
            />
          }
        />
        <Route
          path="/student/profile"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <StudentProfile />
                </Layout>
              }
              allowedRole="student"
            />
          }
        />
        <Route
          path="/student/attendance"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <StudentAttendance />
                </Layout>
              }
              allowedRole="student"
            />
          }
        />
        <Route
          path="/student/assignments"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <StudentAssignments />
                </Layout>
              }
              allowedRole="student"
            />
          }
        />
        <Route
          path="/student/exams"
          element={
            <ProtectedRoute
              element={
                <Layout>
                  <StudentExams />
                </Layout>
              }
              allowedRole="student"
            />
          }
        />

        {/* Default Redirect */}
        <Route
          path="/"
          element={
            user ? (
              <Navigate to={user.role === 'admin' ? '/admin' : '/student'} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
      </Routes>
    </Router>
  );
}

export default App;