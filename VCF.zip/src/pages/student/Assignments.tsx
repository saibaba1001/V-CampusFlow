import React, { useState, useEffect } from 'react';
import { Calendar, BookOpen, Clock, Book, Search, AlertCircle } from 'lucide-react';
import { getAssignments } from '../../lib/assignments';
import { Assignment } from '../../lib/supabase';
import DashboardHeader from '../../components/DashboardHeader';

const StudentAssignments: React.FC = () => {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [filteredAssignments, setFilteredAssignments] = useState<Assignment[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchAssignments = async () => {
      setLoading(true);
      try {
        const fetchedAssignments = await getAssignments();
        setAssignments(fetchedAssignments);
        setFilteredAssignments(fetchedAssignments);
      } catch (err) {
        console.error('Error fetching assignments:', err);
        setError('Failed to load assignments');
      } finally {
        setLoading(false);
      }
    };
    
    fetchAssignments();
  }, []);
  
  useEffect(() => {
    if (searchTerm) {
      const filtered = assignments.filter(
        (assignment) =>
          assignment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          assignment.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
          assignment.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredAssignments(filtered);
    } else {
      setFilteredAssignments(assignments);
    }
  }, [searchTerm, assignments]);
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  const getDaysRemaining = (dueDateString: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const dueDate = new Date(dueDateString);
    dueDate.setHours(0, 0, 0, 0);
    
    const differenceInTime = dueDate.getTime() - today.getTime();
    const differenceInDays = Math.ceil(differenceInTime / (1000 * 3600 * 24));
    
    if (differenceInDays < 0) {
      return 'Overdue';
    } else if (differenceInDays === 0) {
      return 'Due Today';
    } else if (differenceInDays === 1) {
      return '1 day remaining';
    } else {
      return `${differenceInDays} days remaining`;
    }
  };
  
  const getStatusClass = (dueDateString: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const dueDate = new Date(dueDateString);
    dueDate.setHours(0, 0, 0, 0);
    
    const differenceInTime = dueDate.getTime() - today.getTime();
    const differenceInDays = Math.ceil(differenceInTime / (1000 * 3600 * 24));
    
    if (differenceInDays < 0) {
      return 'bg-red-100 text-red-800';
    } else if (differenceInDays <= 2) {
      return 'bg-yellow-100 text-yellow-800';
    } else {
      return 'bg-green-100 text-green-800';
    }
  };
  
  return (
    <div>
      <DashboardHeader 
        title="Assignments" 
        subtitle="View and track your course assignments" 
      />
      
      <div className="mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-student-500 focus:ring-student-500 border p-2"
            placeholder="Search assignments by title, course, or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      
      {loading ? (
        <div className="flex justify-center p-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-student-700"></div>
        </div>
      ) : filteredAssignments.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <BookOpen className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No assignments found</h3>
          <p className="text-gray-500">
            {searchTerm
              ? `No assignments matching "${searchTerm}"`
              : "You don't have any assignments yet"}
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredAssignments.map((assignment) => (
            <div 
              key={assignment.id} 
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow animate-fade-in"
            >
              <div className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-1">
                      {assignment.title}
                    </h3>
                    <div className="flex items-center mb-2 text-gray-600">
                      <Book className="w-4 h-4 mr-1" />
                      <span>{assignment.course}</span>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusClass(assignment.due_date)}`}>
                    {getDaysRemaining(assignment.due_date)}
                  </div>
                </div>
                
                <div className="mb-4">
                  <p className="text-gray-600">{assignment.description}</p>
                </div>
                
                <div className="flex items-center text-sm text-gray-500">
                  <Calendar className="w-4 h-4 mr-1" />
                  <span>Due: {formatDate(assignment.due_date)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default StudentAssignments;