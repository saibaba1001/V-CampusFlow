import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  User, 
  Calendar, 
  CheckCircle, 
  BookOpen,
  Clock,
  ArrowRight
} from 'lucide-react';
import { getStudentByUserId } from '../../lib/students';
import { getAttendanceStats } from '../../lib/attendance';
import { getAssignments } from '../../lib/assignments';
import { getExams } from '../../lib/exams';
import { useUserStore } from '../../store/userStore';
import DashboardHeader from '../../components/DashboardHeader';
import StatsCard from '../../components/StatsCard';
import Button from '../../components/Button';

const StudentDashboard: React.FC = () => {
  const { user } = useUserStore();
  const [studentProfile, setStudentProfile] = useState<any>(null);
  const [attendanceStats, setAttendanceStats] = useState<{
    total: number;
    present: number;
    percentage: number;
  }>({ total: 0, present: 0, percentage: 0 });
  const [upcomingExams, setUpcomingExams] = useState<any[]>([]);
  const [assignments, setAssignments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      
      setLoading(true);
      try {
        // Fetch student profile
        const profile = await getStudentByUserId(user.id);
        setStudentProfile(profile);
        
        if (profile) {
          // Fetch attendance stats
          const stats = await getAttendanceStats(profile.id);
          setAttendanceStats(stats);
          
          // Fetch assignments
          const allAssignments = await getAssignments();
          setAssignments(allAssignments);
          
          // Fetch upcoming exams
          const allExams = await getExams();
          const today = new Date();
          
          // Filter exams that are upcoming
          const upcoming = allExams
            .filter(exam => new Date(exam.date) >= today)
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            .slice(0, 3); // Get only the next 3 exams
            
          setUpcomingExams(upcoming);
        }
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load data');
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [user]);
  
  if (loading) {
    return (
      <div className="flex justify-center p-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-student-700"></div>
      </div>
    );
  }
  
  if (!studentProfile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-medium text-gray-900 mb-2">Student Profile Not Found</h3>
        <p className="text-gray-500 mb-6">
          Your user account is not associated with a student profile yet.
          Please contact an administrator to set up your student profile.
        </p>
      </div>
    );
  }
  
  return (
    <div>
      <DashboardHeader 
        title={`Welcome, ${studentProfile.name}`} 
        subtitle={`${studentProfile.course} • Year ${studentProfile.year}`} 
      />
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <StatsCard 
          title="Attendance Rate" 
          value={`${attendanceStats.percentage}%`} 
          icon={<CheckCircle className="w-6 h-6" />} 
          color="bg-student-500"
        />
        <StatsCard 
          title="Days Present" 
          value={attendanceStats.present} 
          icon={<Calendar className="w-6 h-6" />}
          color="bg-emerald-500" 
        />
        <StatsCard 
          title="Upcoming Exams" 
          value={upcomingExams.length} 
          icon={<BookOpen className="w-6 h-6" />}
          color="bg-amber-500" 
        />
      </div>
      
      {/* Mark Attendance */}
      <div className="bg-gradient-to-r from-student-600 to-student-800 rounded-lg shadow-lg p-6 text-white mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold mb-2">Mark Today's Attendance</h2>
            <p className="text-student-100">
              Use face recognition to quickly mark your attendance for today
            </p>
          </div>
          <Link to="/student/attendance">
            <Button
              variant="primary"
              className="bg-white text-student-700 hover:bg-student-100"
              rightIcon={<ArrowRight className="w-5 h-5" />}
            >
              Mark Attendance
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upcoming Exams */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Upcoming Exams</h2>
            <Link to="/student/exams" className="text-student-600 text-sm font-medium flex items-center">
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          
          {upcomingExams.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No upcoming exams found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingExams.map((exam) => (
                <div 
                  key={exam.id} 
                  className="border border-gray-200 rounded-lg p-4 hover:border-student-200 hover:bg-student-50 transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-gray-900">{exam.title}</h3>
                      <p className="text-gray-500 text-sm">{exam.course}</p>
                    </div>
                    <div className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-xs font-semibold">
                      Exam
                    </div>
                  </div>
                  
                  <div className="mt-3 flex items-center text-sm text-gray-500">
                    <Calendar className="w-4 h-4 mr-1" />
                    {new Date(exam.date).toLocaleDateString()}
                    <span className="mx-2">•</span>
                    <Clock className="w-4 h-4 mr-1" />
                    {exam.time}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Assignments */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Assignments</h2>
            <Link to="/student/assignments" className="text-student-600 text-sm font-medium flex items-center">
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          
          {assignments.length === 0 ? (
            <div className="text-center py-8">
              <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No assignments found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {assignments.slice(0, 3).map((assignment) => (
                <div 
                  key={assignment.id} 
                  className="border border-gray-200 rounded-lg p-4 hover:border-student-200 hover:bg-student-50 transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-gray-900">{assignment.title}</h3>
                      <p className="text-gray-500 text-sm">{assignment.course}</p>
                    </div>
                    <div className="bg-student-100 text-student-800 px-3 py-1 rounded-full text-xs font-semibold">
                      Assignment
                    </div>
                  </div>
                  
                  <div className="mt-3 flex items-center text-sm text-gray-500">
                    <Calendar className="w-4 h-4 mr-1" />
                    Due: {new Date(assignment.due_date).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;