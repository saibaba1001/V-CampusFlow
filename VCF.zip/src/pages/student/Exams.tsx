import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Clock, 
  Book, 
  MapPin, 
  Search, 
  AlertCircle,
  CalendarCheck
} from 'lucide-react';
import { getExams } from '../../lib/exams';
import { Exam } from '../../lib/supabase';
import DashboardHeader from '../../components/DashboardHeader';

const StudentExams: React.FC = () => {
  const [exams, setExams] = useState<Exam[]>([]);
  const [filteredExams, setFilteredExams] = useState<Exam[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchExams = async () => {
      setLoading(true);
      try {
        const fetchedExams = await getExams();
        setExams(fetchedExams);
        setFilteredExams(fetchedExams);
      } catch (err) {
        console.error('Error fetching exams:', err);
        setError('Failed to load exams');
      } finally {
        setLoading(false);
      }
    };
    
    fetchExams();
  }, []);
  
  useEffect(() => {
    if (searchTerm) {
      const filtered = exams.filter(
        (exam) =>
          exam.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          exam.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
          exam.location.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredExams(filtered);
    } else {
      setFilteredExams(exams);
    }
  }, [searchTerm, exams]);
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  const getDaysRemaining = (examDateString: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const examDate = new Date(examDateString);
    examDate.setHours(0, 0, 0, 0);
    
    const differenceInTime = examDate.getTime() - today.getTime();
    const differenceInDays = Math.ceil(differenceInTime / (1000 * 3600 * 24));
    
    if (differenceInDays < 0) {
      return 'Past';
    } else if (differenceInDays === 0) {
      return 'Today';
    } else if (differenceInDays === 1) {
      return 'Tomorrow';
    } else {
      return `${differenceInDays} days remaining`;
    }
  };
  
  const getStatusClass = (examDateString: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const examDate = new Date(examDateString);
    examDate.setHours(0, 0, 0, 0);
    
    const differenceInTime = examDate.getTime() - today.getTime();
    const differenceInDays = Math.ceil(differenceInTime / (1000 * 3600 * 24));
    
    if (differenceInDays < 0) {
      return 'bg-gray-100 text-gray-800';
    } else if (differenceInDays <= 2) {
      return 'bg-red-100 text-red-800';
    } else if (differenceInDays <= 7) {
      return 'bg-yellow-100 text-yellow-800';
    } else {
      return 'bg-green-100 text-green-800';
    }
  };
  
  return (
    <div>
      <DashboardHeader 
        title="Exam Schedule" 
        subtitle="View and track your upcoming exams" 
      />
      
      <div className="mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-student-500 focus:ring-student-500 border p-2"
            placeholder="Search exams by title, course, or location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      
      {loading ? (
        <div className="flex justify-center p-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-student-700"></div>
        </div>
      ) : filteredExams.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <CalendarCheck className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No exams found</h3>
          <p className="text-gray-500">
            {searchTerm
              ? `No exams matching "${searchTerm}"`
              : "You don't have any scheduled exams yet"}
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredExams.map((exam) => (
            <div 
              key={exam.id} 
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow animate-fade-in"
            >
              <div className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-1">
                      {exam.title}
                    </h3>
                    <div className="flex items-center mb-2 text-gray-600">
                      <Book className="w-4 h-4 mr-1" />
                      <span>{exam.course}</span>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusClass(exam.date)}`}>
                    {getDaysRemaining(exam.date)}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span>{formatDate(exam.date)}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>{exam.time}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span>{exam.location}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default StudentExams;