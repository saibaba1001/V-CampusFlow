import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  CheckCircle, 
  Clock, 
  User, 
  AlertCircle,
  ThumbsUp
} from 'lucide-react';
import { getStudentByUserId } from '../../lib/students';
import { getAttendanceByStudent, markAttendance, getAttendanceStats } from '../../lib/attendance';
import { useUserStore } from '../../store/userStore';
import DashboardHeader from '../../components/DashboardHeader';
import Button from '../../components/Button';
import FaceRecognition from '../../components/FaceRecognition';
import ConfirmationModal from '../../components/ConfirmationModal';

const StudentAttendance: React.FC = () => {
  const { user } = useUserStore();
  const [student, setStudent] = useState<any>(null);
  const [attendanceRecords, setAttendanceRecords] = useState<any[]>([]);
  const [attendanceStats, setAttendanceStats] = useState<{
    total: number;
    present: number;
    percentage: number;
  }>({ total: 0, present: 0, percentage: 0 });
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  const [showFaceRecognition, setShowFaceRecognition] = useState(false);
  const [showManualModal, setShowManualModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  
  const [attendanceMarked, setAttendanceMarked] = useState(false);
  
  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      
      setLoading(true);
      try {
        // Fetch student profile
        const profile = await getStudentByUserId(user.id);
        
        // Handle case where no profile exists
        if (!profile) {
          setStudent(null);
          setLoading(false);
          return;
        }
        
        setStudent(profile);
        
        // Only fetch attendance data if we have a valid student profile
        const records = await getAttendanceByStudent(profile.id);
        setAttendanceRecords(records);
        
        const stats = await getAttendanceStats(profile.id);
        setAttendanceStats(stats);
        
        // Check if attendance is already marked for today
        const today = new Date().toISOString().split('T')[0];
        const todayRecord = records.find(record => record.date === today);
        if (todayRecord) {
          setAttendanceMarked(true);
        }
      } catch (err) {
        console.error('Error fetching attendance data:', err);
        setError('Failed to load attendance data');
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [user]);
  
  const handleFaceRecognitionSuccess = async () => {
    try {
      await markAttendance(student.id, 'face');
      setShowFaceRecognition(false);
      setShowSuccessModal(true);
      setAttendanceMarked(true);
      refreshAttendanceData();
    } catch (err) {
      console.error('Error marking attendance:', err);
      setError('Failed to mark attendance');
    }
  };
  
  const handleFaceRecognitionError = (errorMessage: string) => {
    console.error('Face recognition error:', errorMessage);
    setError(`Face recognition failed: ${errorMessage}`);
    setShowFaceRecognition(false);
  };
  
  const handleManualAttendance = async () => {
    try {
      await markAttendance(student.id, 'manual');
      setShowManualModal(false);
      setShowSuccessModal(true);
      setAttendanceMarked(true);
      refreshAttendanceData();
    } catch (err) {
      console.error('Error marking manual attendance:', err);
      setError('Failed to mark attendance');
    }
  };
  
  const refreshAttendanceData = async () => {
    if (!student) return;
    
    try {
      // Refresh attendance records
      const records = await getAttendanceByStudent(student.id);
      setAttendanceRecords(records);
      
      // Refresh attendance stats
      const stats = await getAttendanceStats(student.id);
      setAttendanceStats(stats);
    } catch (err) {
      console.error('Error refreshing attendance data:', err);
    }
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  if (loading) {
    return (
      <div className="flex justify-center p-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-student-700"></div>
      </div>
    );
  }
  
  if (!student) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-medium text-gray-900 mb-2">Student Profile Not Found</h3>
        <p className="text-gray-500 mb-6">
          Your user account is not associated with a student profile yet.
          Please contact an administrator to set up your student profile.
        </p>
      </div>
    );
  }
  
  return (
    <div>
      <DashboardHeader 
        title="Attendance" 
        subtitle="Mark and view your attendance records" 
      />
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 text-green-700 rounded-md">
          <p>{success}</p>
        </div>
      )}
      
      {/* Attendance Stats */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Attendance Statistics</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center">
            <div className="text-3xl font-bold text-student-600">{attendanceStats.present}</div>
            <div className="text-gray-500">Days Present</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="text-3xl font-bold text-gray-600">{attendanceStats.total}</div>
            <div className="text-gray-500">Total Days</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="text-3xl font-bold text-student-600">{attendanceStats.percentage}%</div>
            <div className="text-gray-500">Attendance Rate</div>
          </div>
        </div>
        
        <div className="mt-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-gray-700">Attendance Progress</h3>
            <span className="text-xs font-medium text-student-700">{attendanceStats.percentage}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-student-600 h-2.5 rounded-full transition-all duration-500 ease-in-out"
              style={{ width: `${attendanceStats.percentage}%` }}
            ></div>
          </div>
        </div>
      </div>
      
      {/* Mark Attendance */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-lg font-semibold mb-4">Mark Today's Attendance</h2>
        
        {attendanceMarked ? (
          <div className="bg-green-50 rounded-lg p-4 flex items-center mb-4">
            <CheckCircle className="h-6 w-6 text-green-500 mr-3" />
            <div>
              <p className="font-medium text-green-800">Attendance Already Marked</p>
              <p className="text-sm text-green-700">You've already marked your attendance for today.</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 p-5 border border-student-200 rounded-lg bg-student-50">
              <div className="flex items-center mb-3">
                <User className="h-5 w-5 text-student-600 mr-2" />
                <h3 className="font-medium">Face Recognition</h3>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Mark your attendance quickly using face recognition
              </p>
              <Button
                onClick={() => {
                  if (!student.face_data) {
                    setError('You need to register your face first. Go to Profile to register.');
                    return;
                  }
                  setShowFaceRecognition(true);
                }}
                className="w-full"
                disabled={!student.face_data}
              >
                Start Face Recognition
              </Button>
              {!student.face_data && (
                <p className="text-red-500 text-xs mt-2">
                  Face data not registered. Go to Profile to register.
                </p>
              )}
            </div>
            
            <div className="flex-1 p-5 border border-gray-200 rounded-lg">
              <div className="flex items-center mb-3">
                <CheckCircle className="h-5 w-5 text-gray-600 mr-2" />
                <h3 className="font-medium">Manual Attendance</h3>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Use this option if face recognition is not working
              </p>
              <Button
                variant="secondary"
                onClick={() => setShowManualModal(true)}
                className="w-full"
              >
                Mark Manually
              </Button>
            </div>
          </div>
        )}
      </div>
      
      {/* Attendance History */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold">Attendance History</h2>
        </div>
        
        {attendanceRecords.length === 0 ? (
          <div className="p-12 text-center">
            <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No attendance records found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Method
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {attendanceRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatDate(record.date)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {record.time}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {record.status === 'present' ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          Present
                        </span>
                      ) : (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                          Absent
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {record.method === 'face' ? (
                        <span className="flex items-center text-sm text-gray-500">
                          <User className="h-4 w-4 text-student-500 mr-1" />
                          Face
                        </span>
                      ) : (
                        <span className="flex items-center text-sm text-gray-500">
                          <CheckCircle className="h-4 w-4 text-gray-500 mr-1" />
                          Manual
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* Face Recognition Modal */}
      {showFaceRecognition && student.face_data && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-screen items-center justify-center p-4 text-center">
            {/* Background overlay */}
            <div 
              className="fixed inset-0 bg-black/50 transition-opacity" 
              onClick={() => setShowFaceRecognition(false)}
            ></div>
            
            {/* Modal */}
            <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all w-full max-w-lg p-6 animate-fade-in">
              <h2 className="text-lg font-semibold mb-4">Mark Attendance with Face Recognition</h2>
              <FaceRecognition 
                storedFaceData={student.face_data}
                onSuccess={handleFaceRecognitionSuccess}
                onError={handleFaceRecognitionError}
              />
              <div className="mt-4 flex justify-end">
                <Button
                  variant="secondary"
                  onClick={() => setShowFaceRecognition(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Manual Attendance Confirmation Modal */}
      <ConfirmationModal
        isOpen={showManualModal}
        title="Manual Attendance Confirmation"
        message="Are you sure you want to mark your attendance manually for today?"
        onConfirm={handleManualAttendance}
        onCancel={() => setShowManualModal(false)}
      />
      
      {/* Success Modal */}
      <ConfirmationModal
        isOpen={showSuccessModal}
        title="Attendance Marked Successfully"
        message="Your attendance has been marked successfully for today!"
        onConfirm={() => setShowSuccessModal(false)}
        onCancel={() => setShowSuccessModal(false)}
      />
    </div>
  );
};

export default StudentAttendance;