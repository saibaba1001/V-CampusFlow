import React, { useState, useEffect } from 'react';
import { 
  User, 
  Mail, 
  Book, 
  Calendar, 
  School, 
  MapPin, 
  Hash,
  AlertCircle
} from 'lucide-react';
import { getStudentByUserId, updateFaceData } from '../../lib/students';
import { useUserStore } from '../../store/userStore';
import DashboardHeader from '../../components/DashboardHeader';
import Button from '../../components/Button';
import FaceCapture from '../../components/FaceCapture';

const StudentProfile: React.FC = () => {
  const { user } = useUserStore();
  const [student, setStudent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // For face registration
  const [showFaceCapture, setShowFaceCapture] = useState(false);
  
  useEffect(() => {
    const fetchStudent = async () => {
      if (!user) return;
      
      setLoading(true);
      try {
        const profile = await getStudentByUserId(user.id);
        setStudent(profile);
      } catch (err) {
        console.error('Error fetching student profile:', err);
        setError('Failed to load profile data');
      } finally {
        setLoading(false);
      }
    };
    
    fetchStudent();
  }, [user]);
  
  const handleFaceCapture = async (faceData: string) => {
    if (!student) return;
    
    try {
      await updateFaceData(student.id, faceData);
      setStudent({ ...student, face_data: faceData });
      setShowFaceCapture(false);
      setSuccess('Face data updated successfully');
      
      // Clear success message after a few seconds
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error updating face data:', err);
      setError('Failed to update face data');
    }
  };
  
  if (loading) {
    return (
      <div className="flex justify-center p-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-student-700"></div>
      </div>
    );
  }
  
  if (!student) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-medium text-gray-900 mb-2">Student Profile Not Found</h3>
        <p className="text-gray-500 mb-6">
          Your user account is not associated with a student profile yet.
          Please contact an administrator to set up your student profile.
        </p>
      </div>
    );
  }
  
  return (
    <div>
      <DashboardHeader 
        title="My Profile" 
        subtitle="View and update your profile information" 
      />
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 text-green-700 rounded-md">
          <p>{success}</p>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-4">
                <div className="h-24 w-24 rounded-full bg-student-100 flex items-center justify-center">
                  <User className="h-12 w-12 text-student-600" />
                </div>
                {student.face_data && (
                  <div className="absolute -bottom-1 -right-1 bg-green-500 rounded-full p-1">
                    <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                )}
              </div>
              <h2 className="text-xl font-bold text-gray-900 mb-1">{student.name}</h2>
              <p className="text-gray-500 mb-3">{user?.email}</p>
              <div className="flex items-center justify-center mb-4">
                <span className="px-3 py-1 text-xs rounded-full bg-student-100 text-student-800 font-medium">
                  Student
                </span>
              </div>
              <Button
                onClick={() => setShowFaceCapture(true)}
                size="small"
                className="w-full"
              >
                {student.face_data ? 'Update Face Data' : 'Register Face'}
              </Button>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold mb-6">Student Information</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-500">Full Name</h3>
                    <p className="text-base font-medium text-gray-900">{student.name}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-500">Email</h3>
                    <p className="text-base font-medium text-gray-900">{user?.email}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Hash className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-500">Student ID</h3>
                    <p className="text-base font-medium text-gray-900">{student.student_id}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Book className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-500">Course</h3>
                    <p className="text-base font-medium text-gray-900">{student.course}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-500">Year</h3>
                    <p className="text-base font-medium text-gray-900">Year {student.year}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <School className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-gray-500">Face Recognition</h3>
                    {student.face_data ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Registered
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        Not Registered
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Face Registration Modal */}
      {showFaceCapture && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-screen items-center justify-center p-4 text-center">
            {/* Background overlay */}
            <div 
              className="fixed inset-0 bg-black/50 transition-opacity" 
              onClick={() => setShowFaceCapture(false)}
            ></div>
            
            {/* Modal */}
            <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all w-full max-w-lg p-6 animate-fade-in">
              <FaceCapture 
                onCapture={handleFaceCapture} 
                buttonText={student.face_data ? 'Update Face Data' : 'Register Face'}
              />
              <div className="mt-4 flex justify-end">
                <Button
                  variant="secondary"
                  onClick={() => setShowFaceCapture(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentProfile;