import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Users, 
  CheckCircle, 
  CalendarCheck, 
  BookOpen, 
  PlusCircle,
  ArrowRight
} from 'lucide-react';
import { getStudents } from '../../lib/students';
import { getAttendanceByDate } from '../../lib/attendance';
import { getAssignments } from '../../lib/assignments';
import { getExams } from '../../lib/exams';
import DashboardHeader from '../../components/DashboardHeader';
import StatsCard from '../../components/StatsCard';
import Button from '../../components/Button';

const AdminDashboard: React.FC = () => {
  const [studentCount, setStudentCount] = useState(0);
  const [attendanceCount, setAttendanceCount] = useState(0);
  const [assignmentCount, setAssignmentCount] = useState(0);
  const [examCount, setExamCount] = useState(0);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Get student count
        const students = await getStudents();
        setStudentCount(students.length);
        
        // Get today's attendance count
        const today = new Date().toISOString().split('T')[0];
        const attendance = await getAttendanceByDate(today);
        setAttendanceCount(attendance.length);
        
        // Get assignment and exam counts
        const assignments = await getAssignments();
        setAssignmentCount(assignments.length);
        
        const exams = await getExams();
        setExamCount(exams.length);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  return (
    <div>
      <DashboardHeader 
        title="Admin Dashboard" 
        subtitle={`Welcome back, Admin • ${currentDate}`} 
      />
      
      {loading ? (
        <div className="flex justify-center p-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-700"></div>
        </div>
      ) : (
        <>
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard 
              title="Total Students" 
              value={studentCount} 
              icon={<Users className="w-6 h-6" />} 
              color="bg-admin-500"
            />
            <StatsCard 
              title="Today's Attendance" 
              value={attendanceCount} 
              icon={<CheckCircle className="w-6 h-6" />}
              color="bg-green-500" 
            />
            <StatsCard 
              title="Assignments" 
              value={assignmentCount} 
              icon={<BookOpen className="w-6 h-6" />}
              color="bg-yellow-500" 
            />
            <StatsCard 
              title="Upcoming Exams" 
              value={examCount} 
              icon={<CalendarCheck className="w-6 h-6" />}
              color="bg-purple-500" 
            />
          </div>
          
          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Link to="/admin/students" className="block">
                <div className="border border-gray-200 rounded-lg p-4 hover:bg-blue-50 hover:border-blue-200 transition-colors">
                  <div className="flex items-center mb-3">
                    <Users className="w-6 h-6 text-admin-600 mr-2" />
                    <h3 className="font-medium">View Students</h3>
                  </div>
                  <p className="text-sm text-gray-600">
                    Access and manage student records
                  </p>
                </div>
              </Link>
              
              <Link to="/admin/attendance" className="block">
                <div className="border border-gray-200 rounded-lg p-4 hover:bg-green-50 hover:border-green-200 transition-colors">
                  <div className="flex items-center mb-3">
                    <CheckCircle className="w-6 h-6 text-green-600 mr-2" />
                    <h3 className="font-medium">Attendance Records</h3>
                  </div>
                  <p className="text-sm text-gray-600">
                    View and manage attendance data
                  </p>
                </div>
              </Link>
              
              <Link to="/admin/assignments" className="block">
                <div className="border border-gray-200 rounded-lg p-4 hover:bg-yellow-50 hover:border-yellow-200 transition-colors">
                  <div className="flex items-center mb-3">
                    <BookOpen className="w-6 h-6 text-yellow-600 mr-2" />
                    <h3 className="font-medium">Assignments</h3>
                  </div>
                  <p className="text-sm text-gray-600">
                    Create and manage assignments
                  </p>
                </div>
              </Link>
              
              <Link to="/admin/exams" className="block">
                <div className="border border-gray-200 rounded-lg p-4 hover:bg-purple-50 hover:border-purple-200 transition-colors">
                  <div className="flex items-center mb-3">
                    <CalendarCheck className="w-6 h-6 text-purple-600 mr-2" />
                    <h3 className="font-medium">Exam Schedule</h3>
                  </div>
                  <p className="text-sm text-gray-600">
                    Schedule and manage exams
                  </p>
                </div>
              </Link>
            </div>
          </div>
          
          {/* Register New Student Card */}
          <div className="bg-gradient-to-r from-admin-700 to-admin-900 rounded-lg shadow-lg p-6 text-white">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <h2 className="text-xl font-bold mb-2">Register New Students</h2>
                <p className="text-admin-100">
                  Add new students to the system and register their face data for attendance
                </p>
              </div>
              <Link to="/admin/students">
                <Button
                  variant="primary"
                  className="bg-white text-admin-700 hover:bg-admin-100"
                  rightIcon={<ArrowRight className="w-5 h-5" />}
                >
                  Register Now
                </Button>
              </Link>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AdminDashboard;