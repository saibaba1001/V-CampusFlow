import React, { useState, useEffect } from 'react';
import { Calendar, Search, CheckCircle, XCircle } from 'lucide-react';
import { getStudents } from '../../lib/students';
import { getAttendanceByDate } from '../../lib/attendance';
import { Student, Attendance } from '../../lib/supabase';
import DashboardHeader from '../../components/DashboardHeader';

interface AttendanceRecord extends Attendance {
  studentName?: string;
  studentId?: string;
}

const AdminAttendance: React.FC = () => {
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredRecords, setFilteredRecords] = useState<AttendanceRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Fetch students
        const fetchedStudents = await getStudents();
        setStudents(fetchedStudents);
        
        // Fetch attendance for the selected date
        const attendance = await getAttendanceByDate(date);
        
        // Combine attendance with student details
        const recordsWithStudentDetails = attendance.map(record => {
          const student = fetchedStudents.find(s => s.id === record.student_id);
          return {
            ...record,
            studentName: student?.name,
            studentId: student?.student_id,
          };
        });
        
        setAttendanceRecords(recordsWithStudentDetails);
        setFilteredRecords(recordsWithStudentDetails);
      } catch (error) {
        console.error('Error fetching attendance data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [date]);
  
  useEffect(() => {
    if (searchTerm) {
      const filtered = attendanceRecords.filter(
        (record) =>
          record.studentName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          record.studentId?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredRecords(filtered);
    } else {
      setFilteredRecords(attendanceRecords);
    }
  }, [searchTerm, attendanceRecords]);
  
  // Get attendance percentage
  const presentCount = filteredRecords.filter(r => r.status === 'present').length;
  const totalStudents = students.length;
  const attendancePercentage = totalStudents > 0 
    ? Math.round((presentCount / totalStudents) * 100) 
    : 0;
  
  return (
    <div>
      <DashboardHeader 
        title="Attendance Records" 
        subtitle="View and manage student attendance" 
      />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Date Selector */}
        <div className="bg-white rounded-lg shadow-md p-5">
          <div className="flex items-center mb-3">
            <Calendar className="h-5 w-5 text-admin-600 mr-2" />
            <h3 className="text-lg font-medium">Select Date</h3>
          </div>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 px-4 py-2 border"
          />
        </div>
        
        {/* Attendance Summary */}
        <div className="bg-white rounded-lg shadow-md p-5">
          <h3 className="text-lg font-medium mb-3">Attendance Summary</h3>
          <div className="flex justify-between items-center">
            <div>
              <p className="text-gray-500">Present</p>
              <p className="text-2xl font-semibold text-green-600">{presentCount}</p>
            </div>
            <div>
              <p className="text-gray-500">Total</p>
              <p className="text-2xl font-semibold">{totalStudents}</p>
            </div>
            <div>
              <p className="text-gray-500">Percentage</p>
              <p className="text-2xl font-semibold text-admin-600">{attendancePercentage}%</p>
            </div>
          </div>
        </div>
        
        {/* Search Box */}
        <div className="bg-white rounded-lg shadow-md p-5">
          <div className="flex items-center mb-3">
            <Search className="h-5 w-5 text-admin-600 mr-2" />
            <h3 className="text-lg font-medium">Search Students</h3>
          </div>
          <input
            type="text"
            placeholder="Search by name or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 px-4 py-2 border"
          />
        </div>
      </div>
      
      {/* Attendance Progress Bar */}
      <div className="bg-white rounded-lg shadow-md p-5 mb-6">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-medium">Attendance Rate</h3>
          <span className="text-admin-600 font-semibold">{attendancePercentage}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div 
            className="bg-admin-600 h-4 rounded-full transition-all duration-500"
            style={{ width: `${attendancePercentage}%` }}
          ></div>
        </div>
      </div>
      
      {/* Attendance Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {loading ? (
          <div className="flex justify-center p-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-admin-700"></div>
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="p-6 text-center">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-gray-900">No attendance records found</h3>
            <p className="mt-1 text-gray-500">
              {searchTerm
                ? `No records matching "${searchTerm}" for ${new Date(date).toLocaleDateString()}`
                : `No attendance records for ${new Date(date).toLocaleDateString()}`}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Student
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Method
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {record.studentName || 'Unknown Student'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {record.studentId || 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {record.time}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {record.status === 'present' ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          Present
                        </span>
                      ) : (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                          Absent
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {record.method === 'face' ? (
                        <span className="flex items-center text-sm text-gray-500">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                          Face
                        </span>
                      ) : (
                        <span className="flex items-center text-sm text-gray-500">
                          <XCircle className="h-4 w-4 text-amber-500 mr-1" />
                          Manual
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminAttendance;