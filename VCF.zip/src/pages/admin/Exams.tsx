import React, { useState, useEffect } from 'react';
import { 
  CalendarCheck, 
  Plus, 
  Edit, 
  Trash2, 
  Calendar, 
  Clock, 
  MapPin,
  Book,
  AlertCircle
} from 'lucide-react';
import { getExams, createExam, updateExam, deleteExam } from '../../lib/exams';
import { Exam } from '../../lib/supabase';
import DashboardHeader from '../../components/DashboardHeader';
import Button from '../../components/Button';
import ConfirmationModal from '../../components/ConfirmationModal';

const AdminExams: React.FC = () => {
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Form states
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [course, setCourse] = useState('');
  const [location, setLocation] = useState('');
  
  // Delete confirmation
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  
  useEffect(() => {
    fetchExams();
  }, []);
  
  const fetchExams = async () => {
    setLoading(true);
    try {
      const fetchedExams = await getExams();
      setExams(fetchedExams);
    } catch (err) {
      console.error('Error fetching exams:', err);
      setError('Failed to load exams');
    } finally {
      setLoading(false);
    }
  };
  
  const resetForm = () => {
    setTitle('');
    setDate('');
    setTime('');
    setCourse('');
    setLocation('');
    setEditingId(null);
  };
  
  const handleEdit = (exam: Exam) => {
    setTitle(exam.title);
    setDate(exam.date);
    setTime(exam.time);
    setCourse(exam.course);
    setLocation(exam.location);
    setEditingId(exam.id);
    setShowForm(true);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    try {
      if (editingId) {
        // Update existing exam
        await updateExam(editingId, {
          title,
          date,
          time,
          course,
          location,
        });
      } else {
        // Create new exam
        await createExam({
          title,
          date,
          time,
          course,
          location,
        });
      }
      
      // Reset form and refresh exams
      resetForm();
      setShowForm(false);
      fetchExams();
    } catch (err) {
      console.error('Error saving exam:', err);
      setError('Failed to save exam');
    }
  };
  
  const confirmDelete = (id: string) => {
    setDeleteId(id);
    setShowDeleteModal(true);
  };
  
  const handleDelete = async () => {
    if (!deleteId) return;
    
    try {
      await deleteExam(deleteId);
      setShowDeleteModal(false);
      fetchExams();
    } catch (err) {
      console.error('Error deleting exam:', err);
      setError('Failed to delete exam');
    }
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  return (
    <div>
      <DashboardHeader 
        title="Exams Schedule" 
        subtitle="Manage upcoming exams and tests" 
      />
      
      <div className="mb-6">
        <Button
          onClick={() => {
            resetForm();
            setShowForm(!showForm);
          }}
          leftIcon={showForm ? <CalendarCheck className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
          className="bg-admin-600 hover:bg-admin-700"
        >
          {showForm ? 'Close Form' : 'Add New Exam'}
        </Button>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      
      {/* Exam Form */}
      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6 animate-fade-in">
          <h2 className="text-lg font-semibold mb-4">
            {editingId ? 'Edit Exam' : 'Schedule New Exam'}
          </h2>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                  Exam Title *
                </label>
                <input
                  id="title"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 px-4 py-2 border"
                  placeholder="e.g., Midterm Examination"
                />
              </div>
              
              <div>
                <label htmlFor="course" className="block text-sm font-medium text-gray-700 mb-1">
                  Course *
                </label>
                <input
                  id="course"
                  type="text"
                  value={course}
                  onChange={(e) => setCourse(e.target.value)}
                  required
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 px-4 py-2 border"
                  placeholder="e.g., Computer Science 101"
                />
              </div>
              
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                  Location *
                </label>
                <input
                  id="location"
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 px-4 py-2 border"
                  placeholder="e.g., Room 201, Building A"
                />
              </div>
              
              <div>
                <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">
                  Date *
                </label>
                <input
                  id="date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 px-4 py-2 border"
                />
              </div>
              
              <div>
                <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">
                  Time *
                </label>
                <input
                  id="time"
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  required
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 px-4 py-2 border"
                />
              </div>
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  resetForm();
                  setShowForm(false);
                }}
              >
                Cancel
              </Button>
              <Button type="submit">
                {editingId ? 'Update Exam' : 'Schedule Exam'}
              </Button>
            </div>
          </form>
        </div>
      )}
      
      {/* Exams List */}
      {loading ? (
        <div className="flex justify-center p-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-admin-700"></div>
        </div>
      ) : exams.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <CalendarCheck className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No exams scheduled</h3>
          <p className="text-gray-500 mb-6">Start creating exam schedules for your courses</p>
          <Button
            onClick={() => setShowForm(true)}
            leftIcon={<Plus className="w-5 h-5" />}
          >
            Schedule Your First Exam
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exams.map((exam) => (
            <div 
              key={exam.id} 
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow animate-fade-in"
            >
              <div className="bg-admin-600 p-4 text-white">
                <h3 className="font-semibold text-lg truncate">{exam.title}</h3>
              </div>
              
              <div className="p-5">
                <div className="flex items-center mb-3 text-gray-600">
                  <Book className="w-5 h-5 mr-2" />
                  <span>{exam.course}</span>
                </div>
                
                <div className="flex items-center mb-3 text-gray-600">
                  <Calendar className="w-5 h-5 mr-2" />
                  <span>{formatDate(exam.date)}</span>
                </div>
                
                <div className="flex items-center mb-3 text-gray-600">
                  <Clock className="w-5 h-5 mr-2" />
                  <span>{exam.time}</span>
                </div>
                
                <div className="flex items-center mb-3 text-gray-600">
                  <MapPin className="w-5 h-5 mr-2" />
                  <span>{exam.location}</span>
                </div>
                
                <div className="flex justify-end space-x-2 mt-4">
                  <button
                    onClick={() => handleEdit(exam)}
                    className="p-2 text-gray-600 hover:text-admin-600 hover:bg-admin-50 rounded-full transition-colors"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => confirmDelete(exam.id)}
                    className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={showDeleteModal}
        title="Delete Exam"
        message="Are you sure you want to delete this exam? This action cannot be undone."
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteModal(false)}
      />
    </div>
  );
};

export default AdminExams;