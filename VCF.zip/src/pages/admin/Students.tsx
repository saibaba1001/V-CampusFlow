import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  User, 
  Search, 
  Plus, 
  Edit, 
  Trash2, 
  ChevronRight,
  AlertCircle
} from 'lucide-react';
import { getStudents, deleteStudent } from '../../lib/students';
import { Student } from '../../lib/supabase';
import DashboardHeader from '../../components/DashboardHeader';
import Button from '../../components/Button';
import ConfirmationModal from '../../components/ConfirmationModal';

const AdminStudents: React.FC = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  
  // Form states
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [course, setCourse] = useState('');
  const [year, setYear] = useState('1');
  const [formError, setFormError] = useState<string | null>(null);
  
  useEffect(() => {
    fetchStudents();
  }, []);
  
  useEffect(() => {
    if (searchTerm) {
      const filtered = students.filter(
        (student) =>
          student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.student_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.course.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredStudents(filtered);
    } else {
      setFilteredStudents(students);
    }
  }, [searchTerm, students]);
  
  const fetchStudents = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const fetchedStudents = await getStudents();
      setStudents(fetchedStudents);
      setFilteredStudents(fetchedStudents);
    } catch (err) {
      console.error('Error fetching students:', err);
      setError('Failed to load students. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    
    // Validation
    if (!email || !name || !studentId || !course || !year) {
      setFormError('All fields are required');
      return;
    }
    
    try {
      // TODO: Implement student creation in admin/StudentDetail.tsx
      setShowAddModal(false);
      
      // Reset form
      setEmail('');
      setName('');
      setStudentId('');
      setCourse('');
      setYear('1');
      
      // Refresh student list
      fetchStudents();
    } catch (err) {
      console.error('Error creating student:', err);
      setFormError('Failed to create student. Please try again.');
    }
  };
  
  const confirmDelete = (id: string) => {
    setSelectedStudentId(id);
    setShowDeleteModal(true);
  };
  
  const handleDeleteStudent = async () => {
    if (!selectedStudentId) return;
    
    try {
      await deleteStudent(selectedStudentId);
      setShowDeleteModal(false);
      setSelectedStudentId(null);
      
      // Refresh student list
      fetchStudents();
    } catch (err) {
      console.error('Error deleting student:', err);
      setError('Failed to delete student. Please try again.');
    }
  };
  
  return (
    <div>
      <DashboardHeader 
        title="Student Management" 
        subtitle="View, add, and manage students" 
      />
      
      <div className="mb-6 flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-admin-500 focus:ring-admin-500 border p-2"
            placeholder="Search students..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Link to="/admin/students/new">
          <Button
            variant="primary"
            leftIcon={<Plus className="w-5 h-5" />}
            className="bg-admin-600 hover:bg-admin-700 w-full sm:w-auto"
          >
            Add New Student
          </Button>
        </Link>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-md flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      
      {loading ? (
        <div className="flex justify-center p-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-admin-700"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {filteredStudents.length === 0 ? (
            <div className="p-6 text-center">
              <User className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">No students found</h3>
              <p className="mt-1 text-gray-500">
                {searchTerm
                  ? `No students matching "${searchTerm}"`
                  : "You haven't added any students yet"}
              </p>
              {!searchTerm && (
                <div className="mt-6">
                  <Link to="/admin/students/new">
                    <Button
                      variant="primary"
                      leftIcon={<Plus className="w-5 h-5" />}
                      className="bg-admin-600 hover:bg-admin-700"
                    >
                      Add New Student
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Student ID
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Course
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Year
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Face Data
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredStudents.map((student) => (
                    <tr key={student.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 bg-admin-100 text-admin-600 rounded-full flex items-center justify-center">
                            <User className="h-5 w-5" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{student.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {student.student_id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {student.course}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {student.year}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {student.face_data ? (
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Registered
                          </span>
                        ) : (
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                            Not Registered
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-3">
                          <Link to={`/admin/students/${student.id}`}>
                            <button className="text-admin-600 hover:text-admin-900">
                              <Edit className="h-5 w-5" />
                            </button>
                          </Link>
                          <button
                            onClick={() => confirmDelete(student.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                          <Link to={`/admin/students/${student.id}`}>
                            <button className="text-gray-600 hover:text-gray-900">
                              <ChevronRight className="h-5 w-5" />
                            </button>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={showDeleteModal}
        title="Delete Student"
        message="Are you sure you want to delete this student? This action cannot be undone."
        onConfirm={handleDeleteStudent}
        onCancel={() => setShowDeleteModal(false)}
      />
    </div>
  );
};

export default AdminStudents;