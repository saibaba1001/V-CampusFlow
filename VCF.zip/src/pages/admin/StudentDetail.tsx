import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  Save, 
  User, 
  ArrowLeft, 
  AlertCircle, 
  Hash, 
  BookOpen,
  Calendar,
  Mail
} from 'lucide-react';
import { getStudentByUserId, updateStudent, createStudent } from '../../lib/students'; // Ensure getStudentById is imported
import { supabase, Student } from '../../lib/supabase';
import DashboardHeader from '../../components/DashboardHeader';
import Button from '../../components/Button';
import FaceCapture from '../../components/FaceCapture';

const AdminStudentDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isNewStudent = id === 'new';
  
  const [student, setStudent] = useState<Partial<Student>>({
    name: '',
    email: '', // Ensure email is initialized
    student_id: '',
    course: '',
    year: 1,
    face_data: undefined,
  });
  
  const [loading, setLoading] = useState(!isNewStudent);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showFaceCapture, setShowFaceCapture] = useState(false);

  useEffect(() => {
    if (!isNewStudent) {
      fetchStudentData();
    }
  }, [id, isNewStudent]);

  const fetchStudentData = async () => {
    if (!id || isNewStudent) return;
    
    setLoading(true);
    try {
      const fetchedStudent = await getStudentByUserId(id);
      if (fetchedStudent) {
        setStudent(fetchedStudent);
      } else {
        setError('Student not found');
      }
    } catch (err) {
      console.error('Error fetching student:', err);
      setError('Failed to load student data');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: student.email || '',
        password: 'temppass123',
        options: {
          data: {
            role: 'student'
          }
        }
      });

      if (authError) throw authError;

      if (!authData.user) throw new Error('Failed to create user account');

      const studentData = {
        ...student,
        email: student.email,
        user_id: authData.user.id
      };

      if (isNewStudent) {
        await createStudent(studentData);
        setSuccess('Student created successfully');
      } else {
        await updateStudent(id!, studentData);
        setSuccess('Student updated successfully');
      }
      navigate('/admin/students');
    } catch (err) {
      console.error('Error saving student:', err);
      setError('Failed to save student data');
    } finally {
      setSaving(false);
    }
  };

  const handleFaceDataCapture = (faceData: string) => {
    setStudent(prev => ({ ...prev, face_data: faceData }));
    setShowFaceCapture(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardHeader
        title={isNewStudent ? "Add New Student" : "Edit Student"}
        icon={<User className="w-6 h-6" />}
      />

      <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <Link
          to="/admin/students"
          className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Students
        </Link>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md flex items-center text-red-700">
            <AlertCircle className="w-5 h-5 mr-2" />
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-md flex items-center text-green-700">
            <AlertCircle className="w-5 h-5 mr-2" />
            {success}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6 bg-white shadow rounded-lg p-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                <User className="w-4 h-4 inline-block mr-1" />
                Full Name
              </label>
              <input
                type="text"
                id="name"
                value={student.name}
                onChange={e => setStudent(prev => ({ ...prev, name: e.target.value }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                required
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                <Mail className="w-4 h-4 inline-block mr-1" />
                Email
              </label>
              <input
                type="email"
                id="email"
                value={student.email}
                onChange={e => setStudent(prev => ({ ...prev, email: e.target.value }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                required
              />
            </div>

            <div>
              <label htmlFor="student_id" className="block text-sm font-medium text-gray-700">
                <Hash className="w-4 h-4 inline-block mr-1" />
                Student ID
              </label>
              <input
                type="text"
                id="student_id"
                value={student.student_id}
                onChange={e => setStudent(prev => ({ ...prev, student_id: e.target.value }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                required
              />
            </div>

            <div>
              <label htmlFor="course" className="block text-sm font-medium text-gray-700">
                <BookOpen className="w-4 h-4 inline-block mr-1" />
                Course
              </label>
              <input
                type="text"
                id="course"
                value={student.course}
                onChange={e => setStudent(prev => ({ ...prev, course: e.target.value }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                required
              />
            </div>

            <div>
              <label htmlFor="year" className="block text-sm font-medium text-gray-700">
                <Calendar className="w-4 h-4 inline-block mr-1" />
                Year
              </label>
              <select
                id="year"
                value={student.year}
                onChange={e => setStudent(prev => ({ ...prev, year: parseInt(e.target.value) }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                required
              >
                <option value={1}>1st Year</option>
                <option value={2}>2nd Year</option>
                <option value={3}>3rd Year</option>
                <option value={4}>4th Year</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Face Data</label>
              <Button
                type="button"
                variant="secondary"
                onClick={() => setShowFaceCapture(true)}
                className="w-full"
              >
                {student.face_data ? 'Update Face Data' : 'Capture Face Data'}
              </Button>
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate('/admin/students')}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="inline-flex items-center"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? 'Saving...' : 'Save Student'}
            </Button>
          </div>
        </form>
      </div>

      {showFaceCapture && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-screen items-center justify-center p-4 text-center">
            <div 
              className="fixed inset-0 bg-black/50 transition-opacity" 
              onClick={() => setShowFaceCapture(false)}
            ></div>
            
            <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all w-full max-w-lg p-6 animate-fade-in">
              <h2 className="text-lg font-semibold mb-4">Mark Attendance with Face Recognition</h2>
              <FaceCapture 
                onCapture={handleFaceDataCapture}
                onClose={() => setShowFaceCapture(false)}
              />
              <div className="mt-4 flex justify-end">
                <Button
                  variant="secondary"
                  onClick={() => setShowFaceCapture(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminStudentDetail;
