/*
  # Create users view for admin access

  1. New View
    - `users` view that provides safe access to auth.users data
    - Only exposes necessary user information
    - Protected by RLS policies

  2. Security
    - Enable RLS on users view
    - Add policy for admin access
*/

-- Create a view for safe access to auth.users
CREATE VIEW users AS
SELECT 
  id,
  email,
  raw_user_meta_data
FROM auth.users;

-- Enable RLS
ALTER VIEW users ENABLE ROW LEVEL SECURITY;

-- Create policy for admin access
CREATE POLICY "Admins can read user data"
  ON users
  FOR SELECT
  TO authenticated
  USING ((auth.jwt() ->> 'role'::text) = 'admin'::text);